<?php
// ============================================
// Local Secrets — DO NOT COMMIT TO GIT
// This file is gitignored for security
// ============================================

// Gemini AI Vision API Key
define('GEMINI_API_KEY_LOCAL', 'AQ.Ab8RN6LU0iTPs72GlUCGC7E_c5krPxyby41-QnIe2QiP2yXrjQ');
